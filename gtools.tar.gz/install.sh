#!/bin/bash

dir=/setup
dir2=/etc/zfs

if [ ! -d $dir ];then
	mkdir $dir
fi
if [ ! -d $dir2 ];then
	mkdir $dir2
fi
wd=$(pwd)
cp -r $wd/$1* $dir/
cp -r $wd/$2* $dir2/

